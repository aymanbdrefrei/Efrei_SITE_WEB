// Éfrei Digital - Script principal
(function(){
  'use strict';

  // Set current year
  var y = document.getElementById('year');
  if(y) y.textContent = new Date().getFullYear();

  // Mobile nav toggle
  var btn = document.getElementById('nav-toggle');
  var list = document.getElementById('nav-list');
  if(btn && list){
    btn.addEventListener('click', function(){
      list.classList.toggle('show');
      var expanded = list.classList.contains('show');
      btn.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    });
  }
  
  // Image-strip slider: auto-scroll, controls and pause on hover
  var strip = document.querySelector('.image-strip');
  if(strip){
    var imgs = Array.prototype.slice.call(strip.querySelectorAll('img'));
    var idx = 0;
    var intervalMs = 3000;
    var sliderTimer = null;
    var prevBtn = document.querySelector('.strip-prev');
    var nextBtn = document.querySelector('.strip-next');
    var dotsContainer = document.querySelector('.strip-dots');

    function showIndex(i){
      if(!imgs[i]) return;
      idx = i;
      strip.scrollTo({ left: imgs[i].offsetLeft - strip.offsetLeft, behavior: 'smooth' });
      updateDots();
    }

    function next(){ showIndex((idx + 1) % imgs.length); }
    function prev(){ showIndex((idx - 1 + imgs.length) % imgs.length); }

    // Build dots
    if(dotsContainer){
      dotsContainer.innerHTML = '';
      imgs.forEach(function(_, i){
        var b = document.createElement('button');
        b.setAttribute('aria-label', 'Aller à l\'image ' + (i+1));
        b.addEventListener('click', function(){ showIndex(i); });
        dotsContainer.appendChild(b);
      });
    }

    function updateDots(){
      if(!dotsContainer) return;
      var buttons = dotsContainer.querySelectorAll('button');
      buttons.forEach(function(b, i){
        b.classList.toggle('active', i === idx);
      });
    }

    if(nextBtn) nextBtn.addEventListener('click', function(){ next(); resetTimer(); });
    if(prevBtn) prevBtn.addEventListener('click', function(){ prev(); resetTimer(); });

    function resetTimer(){
      if(sliderTimer) clearInterval(sliderTimer);
      sliderTimer = setInterval(next, intervalMs);
    }

    // Auto start
    sliderTimer = setInterval(next, intervalMs);

    strip.addEventListener('mouseenter', function(){
      clearInterval(sliderTimer);
      sliderTimer = null;
    });
    strip.addEventListener('mouseleave', function(){
      if(!sliderTimer) sliderTimer = setInterval(next, intervalMs);
    });

    // initialize
    showIndex(0);
  }

  // Form validation for contact page
  var form = document.querySelector('form');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      var name = form.querySelector('input[type="text"]');
      var email = form.querySelector('input[type="email"]');
      var message = form.querySelector('textarea');
      
      if(name && email && message && name.value && email.value && message.value){
        alert('Merci pour votre message! Nous vous répondrons bientôt.');
        form.reset();
      } else {
        alert('Veuillez remplir tous les champs.');
      }
    });
  }

  // Interactive formations on homepage
  var programsLayout = document.querySelector('.programs-layout');
  if(programsLayout){
    var detail = document.getElementById('program-detail');
    var items = programsLayout.querySelectorAll('.prog-item');
    items.forEach(function(a){
      a.addEventListener('click', function(ev){
        ev.preventDefault();
        var text = a.getAttribute('data-desc') || a.textContent;
        if(detail){
          detail.innerHTML = '<strong>' + a.textContent + '</strong><div style="margin-top:6px">' + text + '</div>';
          detail.style.display = 'block';
          detail.scrollIntoView({behavior:'smooth', block:'nearest'});
        }
      });
    });

    // Toggle main program link to scroll to list
    var toggle = document.getElementById('program-toggle');
    if(toggle){
      toggle.addEventListener('click', function(e){
        e.preventDefault();
        var first = programsLayout.querySelector('.prog-item');
        if(first){ first.focus(); first.click(); }
      });
    }
  }

  // Vie Étudiante modal and card interactions
  (function(){
    var cards = document.querySelectorAll('.vie-card');
    var modal = document.getElementById('vie-modal');
    var modalTitle = document.getElementById('modal-title');
    var modalBody = document.getElementById('modal-body');
    var modalClose = modal ? modal.querySelector('.modal-close') : null;

    function openModal(title, body){
      if(!modal) return;
      modalTitle.textContent = title || '';
      modalBody.textContent = body || '';
      modal.setAttribute('aria-hidden','false');
    }
    function closeModal(){
      if(!modal) return;
      modal.setAttribute('aria-hidden','true');
    }

    cards.forEach(function(c){
      c.addEventListener('click', function(){
        openModal(c.getAttribute('data-title'), c.getAttribute('data-desc'));
      });
      c.addEventListener('keydown', function(e){ if(e.key==='Enter' || e.key===' ') { e.preventDefault(); openModal(c.getAttribute('data-title'), c.getAttribute('data-desc')); } });
    });

    if(modalClose) modalClose.addEventListener('click', closeModal);
    if(modal){
      modal.addEventListener('click', function(e){ if(e.target === modal) closeModal(); });
      document.addEventListener('keydown', function(e){ if(e.key === 'Escape') closeModal(); });
    }
  })();

  // International interactions: accordion and counters
  (function(){
    var international = document.getElementById('international');
    if(!international) return;

    // Convert partner list into pills if present
    var partners = international.querySelectorAll('ul');
    // Make simple accordion: any H3 followed by p/ul becomes toggleable
    var headings = international.querySelectorAll('h3');
    headings.forEach(function(h){
      var next = h.nextElementSibling;
      if(!next) return;
      // wrap into accordion structure
      var wrapper = document.createElement('div');
      wrapper.className = 'accordion-section';
      var toggle = document.createElement('div');
      toggle.className = 'accordion-toggle';
      toggle.innerHTML = '<span>' + h.textContent + '</span><span class="chev">›</span>';
      var content = document.createElement('div');
      content.className = 'accordion-content';
      // move next and following siblings (until next h3) into content
      var node = next;
      while(node && node.tagName && node.tagName.toLowerCase() !== 'h3'){
        var toMove = node;
        node = node.nextElementSibling;
        content.appendChild(toMove);
      }
      wrapper.appendChild(toggle);
      wrapper.appendChild(content);
      h.parentNode.insertBefore(wrapper, h);
      // remove original heading
      h.parentNode.removeChild(h);

      toggle.addEventListener('click', function(){
        var open = wrapper.classList.toggle('accordion-open');
        if(open){
          content.style.maxHeight = content.scrollHeight + 'px';
        } else {
          content.style.maxHeight = '0';
        }
      });
    });

    // Counters: animate when visible
    var counters = international.querySelectorAll('.counter-num');
    if(counters.length){
      var io = new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
          if(entry.isIntersecting){
            var el = entry.target;
            var target = parseInt(el.getAttribute('data-target') || el.textContent.replace(/\s+/g,''),10) || 0;
            var start = 0;
            var duration = 900;
            var startTime = null;
            function step(ts){
              if(!startTime) startTime = ts;
              var progress = Math.min((ts - startTime) / duration, 1);
              el.textContent = Math.floor(progress * target).toLocaleString();
              if(progress < 1) requestAnimationFrame(step);
            }
            requestAnimationFrame(step);
            io.unobserve(el);
          }
        });
      }, {threshold:0.25});
      counters.forEach(function(c){ io.observe(c); });
    }
  })();

})();
