// Chatbot Widget avec FAQ intégré
class ChatbotWidget {
  constructor() {
    this.isOpen = false;
    this.faqData = this.getFAQData();
    this.init();
  }

  getFAQData() {
    return {
      "faq": [
        {
          "keywords": ["bonjour", "salut", "hello", "coucou", "hey"],
          "response": "Bonjour ! 👋 Je suis l'assistant virtuel d'Efrei Digital. Comment puis-je vous aider aujourd'hui ?"
        },
        {
          "keywords": ["adresse", "où", "localisation", "campus", "situé", "aller", "trouver"],
          "response": "📍 Le campus Efrei est situé au 30-32 Avenue de la République, 94800 Villejuif. Accessible via le Métro ligne 7 (station Villejuif – Louis Aragon) ou les bus 131, 185, 162."
        },
        {
          "keywords": ["contact", "téléphone", "email", "mail", "joindre", "appeler"],
          "response": "📞 Vous pouvez nous contacter par téléphone au 01 23 45 67 89 ou par email à admissions-info@efrei.fr. Nos horaires : Lundi-Vendredi, 9h00-12h30 / 14h00-17h30."
        },
        {
          "keywords": ["admission", "inscrire", "inscription", "candidature", "postuler", "intégrer"],
          "response": "🎓 Pour les admissions : \n• Post-bac : via Parcoursup\n• Concours Puissance Alpha\n• Admissions parallèles disponibles\n\nContactez admissions-info@efrei.fr pour plus d'informations !"
        },
        {
          "keywords": ["formation", "programme", "cursus", "diplôme", "étude", "études", "proposez"],
          "response": "📚 Efrei propose plusieurs formations :\n• Cycle Ingénieur (5 ans, habilité CTI)\n• BTS (Bac+2)\n• Bachelors (Bac+3)\n• Mastères (Bac+5)\n\nSpécialisations : IA, Cybersécurité, Data Science, Cloud Computing, et plus !"
        },
        {
          "keywords": ["ingénieur", "cycle ingénieur", "cti", "titre ingénieur"],
          "response": "🎓 Le Cycle Ingénieur Efrei est une formation de 5 ans habilitée par la CTI. Elle forme des ingénieurs innovants avec des compétences en sciences, technologies et management. Taux d'insertion : 95% !"
        },
        {
          "keywords": ["bts", "bac+2"],
          "response": "💻 Le BTS Efrei est une formation Bac+2 dans le numérique, accessible après le bac. Formation pratique et professionnalisante avec stages en entreprise."
        },
        {
          "keywords": ["bachelor", "bac+3", "licence"],
          "response": "🎯 Les Bachelors Efrei (Bac+3) offrent des formations spécialisées dans le numérique : développement, cybersécurité, data, etc. Alternance possible !"
        },
        {
          "keywords": ["mastère", "master", "bac+5"],
          "response": "🚀 Les Mastères Efrei (Bac+5) proposent des spécialisations pointues : IA, Big Data, Cybersécurité, Cloud & DevOps, Management du numérique..."
        },
        {
          "keywords": ["alternance", "apprentissage", "contrat"],
          "response": "💼 L'alternance est disponible dans la plupart de nos formations ! Vous combinez cours à l'école et expérience en entreprise. Contactez-nous pour les modalités."
        },
        {
          "keywords": ["stage", "entreprise", "expérience"],
          "response": "🏢 Efrei dispose de 50+ entreprises partenaires. Les stages sont obligatoires et permettent une vraie expérience professionnelle. Taux d'insertion de 95% !"
        },
        {
          "keywords": ["prix", "coût", "frais", "scolarité", "tarif", "payer"],
          "response": "💰 Les frais de scolarité varient selon la formation. Contactez le service admissions (admissions-info@efrei.fr) pour obtenir les tarifs détaillés et les possibilités de financement."
        },
        {
          "keywords": ["bourse", "aide", "financement"],
          "response": "💳 Plusieurs aides sont disponibles : bourses CROUS, alternance (formation financée par l'entreprise), prêts étudiants. Le service admissions peut vous accompagner dans vos démarches."
        },
        {
          "keywords": ["international", "étranger", "erasmus", "mobilité", "partir"],
          "response": "🌍 Efrei offre de nombreuses opportunités internationales : semestres à l'étranger, doubles diplômes, partenariats avec 100+ universités dans le monde, programme Alliance 4EU+."
        },
        {
          "keywords": ["vie étudiante", "association", "club", "activité"],
          "response": "🎉 La vie étudiante à Efrei est riche ! Plus de 30 associations : BDE, BDS, clubs tech, gaming, musique, humanitaire... Événements réguliers sur le campus !"
        },
        {
          "keywords": ["recherche", "laboratoire", "innovation"],
          "response": "🔬 Efrei dispose d'un laboratoire de recherche actif travaillant sur l'IA, la cybersécurité, l'IoT... Les étudiants peuvent participer à des projets innovants comme le projet APRIL (IA et santé)."
        },
        {
          "keywords": ["cybersécurité", "cyber", "sécurité informatique", "hacking"],
          "response": "🔐 La Cybersécurité est une spécialisation phare d'Efrei ! Formation complète sur la protection des systèmes, ethical hacking, cryptographie, analyse de menaces..."
        },
        {
          "keywords": ["ia", "intelligence artificielle", "machine learning", "deep learning"],
          "response": "🤖 L'Intelligence Artificielle est au cœur de nos formations ! Spécialisations en Machine Learning, Deep Learning, NLP, Vision par ordinateur..."
        },
        {
          "keywords": ["data", "données", "big data", "data science"],
          "response": "📊 Data Science et Big Data : apprenez à collecter, analyser et valoriser les données. Python, SQL, Hadoop, Spark, visualisation... Débouchés nombreux !"
        },
        {
          "keywords": ["portes ouvertes", "jpo", "visite", "visiter"],
          "response": "🏫 Nos prochaines Journées Portes Ouvertes : 11 janvier à Villejuif. Venez découvrir le campus, rencontrer les équipes et les étudiants ! Inscription sur notre site."
        },
        {
          "keywords": ["débouché", "métier", "emploi", "travail", "salaire", "carrière"],
          "response": "💼 Débouchés nombreux : Ingénieur logiciel, Data Scientist, Expert Cybersécurité, Chef de projet IT, Architecte Cloud... Salaire moyen à la sortie : 42 000€/an. Taux d'insertion : 95% !"
        },
        {
          "keywords": ["merci", "au revoir", "bye", "ciao"],
          "response": "👋 Merci pour votre visite ! N'hésitez pas à nous contacter pour toute question. À bientôt sur le campus Efrei !"
        },
        {
          "keywords": ["horaire", "heure", "ouverture"],
          "response": "🕐 Horaires du service admissions : Lundi au Vendredi, 9h00-12h30 et 14h00-17h30. Le campus est accessible aux étudiants tous les jours."
        },
        {
          "keywords": ["parcoursup", "post-bac", "après bac"],
          "response": "📝 Pour intégrer Efrei après le bac, inscrivez-vous sur Parcoursup et sélectionnez nos formations. Vous passerez ensuite le concours Puissance Alpha."
        }
      ],
      "default_response": "🤔 Je ne suis pas sûr de comprendre votre question. Voici ce que je peux vous aider :\n\n• Formations (ingénieur, BTS, bachelor, mastère)\n• Admissions et inscriptions\n• Contact et localisation\n• Vie étudiante\n• International\n• Débouchés et métiers\n\nPosez-moi une question sur l'un de ces sujets !"
    };
  }

  init() {
    this.createWidget();
    this.attachEventListeners();
  }

  createWidget() {
    const widgetHTML = `
      <div id="chatbot-widget" class="chatbot-widget">
        <button id="chatbot-toggle" class="chatbot-toggle" aria-label="Ouvrir le chatbot">
          <span class="chat-icon">💬</span>
          <span class="close-icon">✕</span>
        </button>
        
        <div id="chatbot-window" class="chatbot-window">
          <div class="chatbot-header">
            <h3>Assistant Éfrei Digital</h3>
            <button id="chatbot-close" class="chatbot-close-btn" aria-label="Fermer">✕</button>
          </div>
          
          <div id="chatbot-messages" class="chatbot-messages">
            <div class="message bot-message">
              <div class="message-content">
                Bonjour ! 👋 Je suis l'assistant virtuel d'Efrei Digital.<br><br>
                Posez-moi vos questions sur :<br>
                • Les formations (ingénieur, BTS, bachelor, mastère)<br>
                • Les admissions et inscriptions<br>
                • Le campus et la vie étudiante<br>
                • Les débouchés et métiers
              </div>
            </div>
          </div>
          
          <div class="chatbot-input-container">
            <input 
              type="text" 
              id="chatbot-input" 
              class="chatbot-input" 
              placeholder="Posez votre question..."
              aria-label="Message"
            />
            <button id="chatbot-send" class="chatbot-send-btn" aria-label="Envoyer">
              <span>➤</span>
            </button>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', widgetHTML);
  }

  attachEventListeners() {
    const toggle = document.getElementById('chatbot-toggle');
    const closeBtn = document.getElementById('chatbot-close');
    const sendBtn = document.getElementById('chatbot-send');
    const input = document.getElementById('chatbot-input');

    toggle.addEventListener('click', () => this.toggleChat());
    closeBtn.addEventListener('click', () => this.toggleChat());
    sendBtn.addEventListener('click', () => this.sendMessage());
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.sendMessage();
    });
  }

  toggleChat() {
    this.isOpen = !this.isOpen;
    const widget = document.getElementById('chatbot-widget');
    const toggle = document.getElementById('chatbot-toggle');

    if (this.isOpen) {
      widget.classList.add('open');
      toggle.classList.add('active');
      document.getElementById('chatbot-input').focus();
    } else {
      widget.classList.remove('open');
      toggle.classList.remove('active');
    }
  }

  async sendMessage() {
    const input = document.getElementById('chatbot-input');
    const message = input.value.trim();

    if (!message) return;

    // Add user message to chat
    this.addMessage(message, 'user');
    input.value = '';

    // Show typing indicator
    this.showTypingIndicator();

    // Simulate typing delay
    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 500));

    // Find response from FAQ
    const response = this.findResponse(message);
    this.hideTypingIndicator();
    this.addMessage(response, 'bot');
  }

  findResponse(userMessage) {
    // Normaliser le message utilisateur (minuscules, sans accents)
    const normalizedMessage = this.normalizeText(userMessage);

    let bestMatch = null;
    let bestScore = 0;

    // Chercher la meilleure correspondance
    for (const item of this.faqData.faq) {
      let score = 0;
      for (const keyword of item.keywords) {
        const normalizedKeyword = this.normalizeText(keyword);
        if (normalizedMessage.includes(normalizedKeyword)) {
          score += normalizedKeyword.length; // Plus le mot-clé est long, plus il compte
        }
      }
      if (score > bestScore) {
        bestScore = score;
        bestMatch = item;
      }
    }

    // Retourner la réponse trouvée ou la réponse par défaut
    if (bestMatch && bestScore > 0) {
      return bestMatch.response;
    }
    return this.faqData.default_response;
  }

  normalizeText(text) {
    return text
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "") // Supprimer les accents
      .replace(/[^a-z0-9\s]/g, " ") // Garder lettres, chiffres, espaces
      .trim();
  }

  addMessage(content, type) {
    const messagesContainer = document.getElementById('chatbot-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}-message`;

    // Convert line breaks to HTML
    let formattedContent = content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n/g, '<br>');

    messageDiv.innerHTML = `
      <div class="message-content">${formattedContent}</div>
    `;

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  showTypingIndicator() {
    const messagesContainer = document.getElementById('chatbot-messages');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message typing-indicator';
    typingDiv.id = 'typing-indicator';
    typingDiv.innerHTML = `
      <div class="message-content">
        <span class="dot"></span>
        <span class="dot"></span>
        <span class="dot"></span>
      </div>
    `;
    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  hideTypingIndicator() {
    const indicator = document.getElementById('typing-indicator');
    if (indicator) indicator.remove();
  }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new ChatbotWidget();
});
