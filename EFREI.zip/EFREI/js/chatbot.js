// Chatbot Widget with Backend API
class ChatbotWidget {
  constructor() {
    this.isOpen = false;
    this.conversationHistory = [];
    this.init();
  }

  init() {
    this.createWidget();
    this.attachEventListeners();
  }

  createWidget() {
    const widgetHTML = `
      <div id="chatbot-widget" class="chatbot-widget">
        <button id="chatbot-toggle" class="chatbot-toggle" aria-label="Ouvrir le chatbot">
          <span class="chat-icon">💬</span>
          <span class="close-icon">✕</span>
        </button>
        
        <div id="chatbot-window" class="chatbot-window">
          <div class="chatbot-header">
            <h3>Assistant Éfrei Digital</h3>
            <button id="chatbot-close" class="chatbot-close-btn" aria-label="Fermer">✕</button>
          </div>
          
          <div id="chatbot-messages" class="chatbot-messages">
            <div class="message bot-message">
              <div class="message-content">
                Bonjour ! 👋 Je suis votre assistant IA.<br><br>
                Je peux répondre à toutes vos questions sur n'importe quel sujet !<br><br>
                Posez-moi ce que vous voulez 
              </div>
            </div>
          </div>
          
          <div class="chatbot-input-container">
            <input 
              type="text" 
              id="chatbot-input" 
              class="chatbot-input" 
              placeholder="Posez votre question..."
              aria-label="Message"
            />
            <button id="chatbot-send" class="chatbot-send-btn" aria-label="Envoyer">
              <span>➤</span>
            </button>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', widgetHTML);
  }

  attachEventListeners() {
    const toggle = document.getElementById('chatbot-toggle');
    const closeBtn = document.getElementById('chatbot-close');
    const sendBtn = document.getElementById('chatbot-send');
    const input = document.getElementById('chatbot-input');

    toggle.addEventListener('click', () => this.toggleChat());
    closeBtn.addEventListener('click', () => this.toggleChat());
    sendBtn.addEventListener('click', () => this.sendMessage());
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.sendMessage();
    });
  }

  toggleChat() {
    this.isOpen = !this.isOpen;
    const widget = document.getElementById('chatbot-widget');
    const toggle = document.getElementById('chatbot-toggle');

    if (this.isOpen) {
      widget.classList.add('open');
      toggle.classList.add('active');
      document.getElementById('chatbot-input').focus();
    } else {
      widget.classList.remove('open');
      toggle.classList.remove('active');
    }
  }

  async sendMessage() {
    const input = document.getElementById('chatbot-input');
    const message = input.value.trim();

    if (!message) return;

    // Add user message to chat
    this.addMessage(message, 'user');
    input.value = '';

    // Show typing indicator
    this.showTypingIndicator();

    try {
      // Call backend API
      const response = await this.callAPI(message);
      this.hideTypingIndicator();
      this.addMessage(response, 'bot');
    } catch (error) {
      this.hideTypingIndicator();
      this.addMessage(' Erreur de connexion au serveur.', 'bot');
    }
  }

  async callAPI(userMessage) {
    // Réponse statique - pas de backend nécessaire
    return "Merci pour votre message ! Notre équipe vous répondra bientôt. Pour une réponse immédiate, contactez-nous par email à admissions-info@efrei.fr ou par téléphone au 01 23 45 67 89.";
  }

  addMessage(content, type) {
    const messagesContainer = document.getElementById('chatbot-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}-message`;

    // Convert markdown-style formatting to HTML
    let formattedContent = content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // Bold
      .replace(/\*(.*?)\*/g, '<em>$1</em>') // Italic
      .replace(/\n/g, '<br>'); // Line breaks

    messageDiv.innerHTML = `
      <div class="message-content">${formattedContent}</div>
    `;

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  showTypingIndicator() {
    const messagesContainer = document.getElementById('chatbot-messages');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message typing-indicator';
    typingDiv.id = 'typing-indicator';
    typingDiv.innerHTML = `
      <div class="message-content">
        <span class="dot"></span>
        <span class="dot"></span>
        <span class="dot"></span>
      </div>
    `;
    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  hideTypingIndicator() {
    const indicator = document.getElementById('typing-indicator');
    if (indicator) indicator.remove();
  }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new ChatbotWidget();
});
